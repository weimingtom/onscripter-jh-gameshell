#!/bin/sh
cd /home/cpi/work/onscripter_jh_sdl2_fork-master
./onscripter > a.txt 2>&1
